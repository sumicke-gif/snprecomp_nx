// Switch controller input: buttons, sticks and gyro, with a small settings file.
//
// Like switch_platform.cpp this file includes libnx headers, so it keeps its
// interface plain C++ (no N64 runtime headers). N64 button values are
// defined locally.
//
// Layout (same idea as the PC build's twin-stick default, src/main/input_defaults.cpp):
//   left stick      -> C buttons (movement)
//   right stick     -> N64 analog stick (aim)
//   ZR              -> Z (fire)        ZL -> R (jump)
//   B (bottom)      -> A (aim mode)    Y (left) -> B
//   X / A / R3 / R  -> C-left / C-right / C-up / C-down (second bindings)
//   + -> Start, L -> L, D-pad -> D-pad
// Every button can be remapped in sdmc:/switch/snprecomp/input.cfg.
//
// Gyro aiming is turned into reticle movement in degrees (screen space: x to
// the right, y downwards) and handed to the game through snp_switch_gyro_take().

#include <switch.h>

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <map>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>

namespace {

// N64 controller button bits (the values from ultra64.h).
const std::map<std::string, uint16_t> kN64Buttons = {
    { "a", 0x8000 },     { "b", 0x4000 },     { "z", 0x2000 },     { "start", 0x1000 },
    { "dup", 0x0800 },   { "ddown", 0x0400 }, { "dleft", 0x0200 }, { "dright", 0x0100 },
    { "l", 0x0020 },     { "r", 0x0010 },
    { "cup", 0x0008 },   { "cdown", 0x0004 }, { "cleft", 0x0002 }, { "cright", 0x0001 },
};
constexpr uint16_t kCLeft = 0x0002, kCRight = 0x0001, kCUp = 0x0008, kCDown = 0x0004;

// Names usable on the right-hand side of a button setting.
const std::map<std::string, uint64_t> kSwitchButtons = {
    { "A", HidNpadButton_A },       { "B", HidNpadButton_B },       { "X", HidNpadButton_X },
    { "Y", HidNpadButton_Y },       { "L", HidNpadButton_L },       { "R", HidNpadButton_R },
    { "ZL", HidNpadButton_ZL },     { "ZR", HidNpadButton_ZR },     { "PLUS", HidNpadButton_Plus },
    { "MINUS", HidNpadButton_Minus }, { "DUP", HidNpadButton_Up },  { "DDOWN", HidNpadButton_Down },
    { "DLEFT", HidNpadButton_Left }, { "DRIGHT", HidNpadButton_Right },
    { "STICKL", HidNpadButton_StickL }, { "STICKR", HidNpadButton_StickR },
};

const char* kDefaultConfig =
    "# Sin and Punishment (Switch) controller settings.\n"
    "# Edit this file, then restart the app. Lines starting with # are comments.\n"
    "\n"
    "# --- Gyro aiming ---\n"
    "gyro = on             # on or off\n"
    "gyro_axis = yaw       # which rotation moves the reticle left and right: yaw or roll\n"
    "gyro_sens_x = 1.0     # horizontal sensitivity\n"
    "gyro_sens_y = 1.0     # vertical sensitivity\n"
    "gyro_invert_x = off   # flip the horizontal direction\n"
    "gyro_invert_y = off   # flip the vertical direction\n"
    "gyro_deadzone = 0.5   # ignore turning slower than this (degrees per second)\n"
    "gyro_unit_scale = 360 # converts the console's gyro units to degrees per second\n"
    "gyro_debug = off      # on: write raw gyro values to log.txt (for calibrating)\n"
    "\n"
    "# --- Sticks ---\n"
    "stick_deadzone = 0.15 # right stick (aim) deadzone, 0 to 0.9\n"
    "c_threshold = 0.45    # how far the left stick must go to press a C button\n"
    "\n"
    "# --- Buttons: N64 button = Switch button (several allowed, separated by commas) ---\n"
    "# Switch buttons: A B X Y L R ZL ZR PLUS MINUS DUP DDOWN DLEFT DRIGHT STICKL STICKR\n"
    "a = B\n"
    "b = Y\n"
    "z = ZR\n"
    "r = ZL\n"
    "l = L\n"
    "start = PLUS\n"
    "dup = DUP\n"
    "ddown = DDOWN\n"
    "dleft = DLEFT\n"
    "dright = DRIGHT\n"
    "cup = STICKR\n"
    "cdown = R\n"
    "cleft = X\n"
    "cright = A\n";

struct Config {
    bool gyro = true;
    bool gyro_roll = false; // false = yaw, true = roll
    float sens_x = 1.0f;
    float sens_y = 1.0f;
    bool invert_x = false;
    bool invert_y = false;
    float gyro_deadzone = 0.5f;
    float unit_scale = 360.0f;
    bool debug = false;
    float stick_deadzone = 0.15f;
    float c_threshold = 0.45f;
    std::map<std::string, std::vector<uint64_t>> buttons;
};

Config g_cfg;
PadState g_pad;

HidSixAxisSensorHandle g_handheld;
HidSixAxisSensorHandle g_fullkey;
HidSixAxisSensorHandle g_dual[2];
bool g_gyro_ready = false;
uint64_t g_last_sample = 0;

std::mutex g_mutex;
uint16_t g_buttons = 0;
float g_stick_x = 0.0f;
float g_stick_y = 0.0f;
float g_gyro_dx = 0.0f;
float g_gyro_dy = 0.0f;

std::string trim(const std::string& s) {
    size_t b = 0, e = s.size();
    while (b < e && std::isspace(static_cast<unsigned char>(s[b]))) b++;
    while (e > b && std::isspace(static_cast<unsigned char>(s[e - 1]))) e--;
    return s.substr(b, e - b);
}

std::string lower(std::string s) {
    for (char& c : s) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return s;
}

std::string upper(std::string s) {
    for (char& c : s) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
    return s;
}

bool parse_bool(const std::string& v, bool fallback) {
    std::string s = lower(v);
    if (s == "on" || s == "true" || s == "yes" || s == "1") return true;
    if (s == "off" || s == "false" || s == "no" || s == "0") return false;
    return fallback;
}

float parse_float(const std::string& v, float fallback) {
    char* end = nullptr;
    float f = std::strtof(v.c_str(), &end);
    return (end != v.c_str()) ? f : fallback;
}

void apply_setting(const std::string& key, const std::string& value) {
    if (key == "gyro") g_cfg.gyro = parse_bool(value, g_cfg.gyro);
    else if (key == "gyro_axis") g_cfg.gyro_roll = (lower(value) == "roll");
    else if (key == "gyro_sens_x") g_cfg.sens_x = parse_float(value, g_cfg.sens_x);
    else if (key == "gyro_sens_y") g_cfg.sens_y = parse_float(value, g_cfg.sens_y);
    else if (key == "gyro_invert_x") g_cfg.invert_x = parse_bool(value, g_cfg.invert_x);
    else if (key == "gyro_invert_y") g_cfg.invert_y = parse_bool(value, g_cfg.invert_y);
    else if (key == "gyro_deadzone") g_cfg.gyro_deadzone = std::max(0.0f, parse_float(value, g_cfg.gyro_deadzone));
    else if (key == "gyro_unit_scale") g_cfg.unit_scale = parse_float(value, g_cfg.unit_scale);
    else if (key == "gyro_debug") g_cfg.debug = parse_bool(value, g_cfg.debug);
    else if (key == "stick_deadzone") g_cfg.stick_deadzone = std::clamp(parse_float(value, g_cfg.stick_deadzone), 0.0f, 0.9f);
    else if (key == "c_threshold") g_cfg.c_threshold = std::clamp(parse_float(value, g_cfg.c_threshold), 0.1f, 0.95f);
    else if (kN64Buttons.count(key) != 0) {
        std::vector<uint64_t> masks;
        std::stringstream ss(value);
        std::string item;
        while (std::getline(ss, item, ',')) {
            auto it = kSwitchButtons.find(upper(trim(item)));
            if (it != kSwitchButtons.end()) {
                masks.push_back(it->second);
            } else if (!trim(item).empty()) {
                printf("[snp-switch] input.cfg: unknown Switch button '%s'\n", trim(item).c_str());
            }
        }
        g_cfg.buttons[key] = masks;
    } else {
        printf("[snp-switch] input.cfg: unknown setting '%s'\n", key.c_str());
    }
}

void load_config(const char* path) {
    // Start from the built-in defaults, then apply the file on top.
    {
        std::stringstream defaults(kDefaultConfig);
        std::string line;
        while (std::getline(defaults, line)) {
            size_t hash = line.find('#');
            if (hash != std::string::npos) line.erase(hash);
            size_t eq = line.find('=');
            if (eq == std::string::npos) continue;
            apply_setting(lower(trim(line.substr(0, eq))), trim(line.substr(eq + 1)));
        }
    }

    std::ifstream in(path);
    if (!in) {
        std::ofstream out(path);
        if (out) {
            out << kDefaultConfig;
            printf("[snp-switch] wrote default settings to %s\n", path);
        }
        return;
    }
    std::string line;
    while (std::getline(in, line)) {
        size_t hash = line.find('#');
        if (hash != std::string::npos) line.erase(hash);
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        apply_setting(lower(trim(line.substr(0, eq))), trim(line.substr(eq + 1)));
    }
    printf("[snp-switch] loaded settings from %s\n", path);
}

// Radial deadzone: below it the stick reads 0, above it the range is stretched back to 0..1.
void apply_deadzone(float& x, float& y, float deadzone) {
    float mag = std::sqrt(x * x + y * y);
    if (mag < deadzone) {
        x = 0.0f;
        y = 0.0f;
        return;
    }
    float scaled = std::min(1.0f, (mag - deadzone) / (1.0f - deadzone));
    x = x / mag * scaled;
    y = y / mag * scaled;
}

HidSixAxisSensorHandle* active_gyro() {
    u32 style = padGetStyleSet(&g_pad);
    if (style & HidNpadStyleTag_NpadHandheld) return &g_handheld;
    if (style & HidNpadStyleTag_NpadFullKey) return &g_fullkey;
    if (style & HidNpadStyleTag_NpadJoyDual) return &g_dual[1]; // the right Joy-Con
    return &g_handheld;
}

void poll_gyro() {
    if (!g_gyro_ready || !g_cfg.gyro) {
        return;
    }
    HidSixAxisSensorState states[8];
    size_t n = hidGetSixAxisSensorStates(*active_gyro(), states, 8);
    float add_x = 0.0f, add_y = 0.0f;
    static auto last_debug = std::chrono::steady_clock::now();
    static bool printed_first = false;

    // states[0] is the newest; walk oldest to newest and use each sample once.
    for (size_t k = n; k-- > 0;) {
        const HidSixAxisSensorState& st = states[k];
        if (st.sampling_number <= g_last_sample) {
            continue;
        }
        g_last_sample = st.sampling_number;
        double dt = st.delta_time * 1e-9;
        if (dt <= 0.0 || dt > 0.1) {
            dt = 0.005;
        }
        float pitch = st.angular_velocity.x * g_cfg.unit_scale;
        float yaw = st.angular_velocity.y * g_cfg.unit_scale;
        float roll = st.angular_velocity.z * g_cfg.unit_scale;

        // Right-hand rule, console held upright facing you: turning left is a positive
        // yaw, tilting the top towards you is a positive pitch. Screen space has x to
        // the right and y downwards, hence the signs. Flip them in input.cfg if needed.
        float horizontal = -(g_cfg.gyro_roll ? roll : yaw);
        float vertical = pitch;
        if (g_cfg.invert_x) horizontal = -horizontal;
        if (g_cfg.invert_y) vertical = -vertical;
        if (std::fabs(horizontal) < g_cfg.gyro_deadzone) horizontal = 0.0f;
        if (std::fabs(vertical) < g_cfg.gyro_deadzone) vertical = 0.0f;
        add_x += horizontal * g_cfg.sens_x * static_cast<float>(dt);
        add_y += vertical * g_cfg.sens_y * static_cast<float>(dt);

        if (g_cfg.debug) {
            auto now = std::chrono::steady_clock::now();
            float peak = std::max({ std::fabs(pitch), std::fabs(yaw), std::fabs(roll) });
            bool moving = peak > 10.0f;
            if ((moving && now - last_debug > std::chrono::milliseconds(300)) || !printed_first) {
                last_debug = now;
                printed_first = true;
                printf("[snp-switch] gyro raw x=%.3f y=%.3f z=%.3f | scaled pitch=%.1f yaw=%.1f roll=%.1f deg/s\n",
                       st.angular_velocity.x, st.angular_velocity.y, st.angular_velocity.z, pitch, yaw, roll);
            }
        }
    }

    if (add_x != 0.0f || add_y != 0.0f) {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_gyro_dx += add_x;
        g_gyro_dy += add_y;
    }
}

} // namespace

bool snp_switch_input_init(const char* config_path) {
    load_config(config_path);

    padConfigureInput(1, HidNpadStyleSet_NpadStandard);
    padInitializeDefault(&g_pad);

    // Six-axis (gyro) handles for every way a controller can be connected.
    bool ok = true;
    ok &= R_SUCCEEDED(hidGetSixAxisSensorHandles(&g_handheld, 1, HidNpadIdType_Handheld, HidNpadStyleTag_NpadHandheld));
    ok &= R_SUCCEEDED(hidGetSixAxisSensorHandles(&g_fullkey, 1, HidNpadIdType_No1, HidNpadStyleTag_NpadFullKey));
    ok &= R_SUCCEEDED(hidGetSixAxisSensorHandles(g_dual, 2, HidNpadIdType_No1, HidNpadStyleTag_NpadJoyDual));
    if (ok) {
        hidStartSixAxisSensor(g_handheld);
        hidStartSixAxisSensor(g_fullkey);
        hidStartSixAxisSensor(g_dual[0]);
        hidStartSixAxisSensor(g_dual[1]);
        g_gyro_ready = true;
    }
    printf("[snp-switch] input ready (gyro %s, %s)\n", g_gyro_ready ? "available" : "unavailable", g_cfg.gyro ? "on" : "off");
    return true;
}

// Called once per frame by the runtime.
void snp_switch_input_poll() {
    padUpdate(&g_pad);
    u64 down = padGetButtons(&g_pad);

    uint16_t out = 0;
    for (const auto& [name, bit] : kN64Buttons) {
        auto it = g_cfg.buttons.find(name);
        if (it == g_cfg.buttons.end()) continue;
        for (uint64_t mask : it->second) {
            if (down & mask) {
                out |= bit;
                break;
            }
        }
    }

    HidAnalogStickState left = padGetStickPos(&g_pad, 0);
    float lx = left.x / 32767.0f;
    float ly = left.y / 32767.0f;
    if (lx < -g_cfg.c_threshold) out |= kCLeft;
    if (lx > g_cfg.c_threshold) out |= kCRight;
    if (ly > g_cfg.c_threshold) out |= kCUp;
    if (ly < -g_cfg.c_threshold) out |= kCDown;

    HidAnalogStickState right = padGetStickPos(&g_pad, 1);
    float rx = right.x / 32767.0f;
    float ry = right.y / 32767.0f;
    apply_deadzone(rx, ry, g_cfg.stick_deadzone);

    poll_gyro();

    static uint16_t last_logged = 0xFFFF;
    if (out != last_logged) {
        last_logged = out;
        printf("[snp-switch] input: N64 buttons 0x%04x\n", out);
    }

    std::lock_guard<std::mutex> lock(g_mutex);
    g_buttons = out;
    g_stick_x = rx;
    g_stick_y = ry;
}

// The state captured by the last poll. Only controller 0 exists.
bool snp_switch_input_get(int controller, uint16_t* buttons, float* x, float* y) {
    if (controller != 0) {
        return false;
    }
    std::lock_guard<std::mutex> lock(g_mutex);
    if (buttons != nullptr) *buttons = g_buttons;
    if (x != nullptr) *x = g_stick_x;
    if (y != nullptr) *y = g_stick_y;
    return true;
}

// Gyro movement since the last call, in degrees: dx to the right, dy downwards.
void snp_switch_gyro_take(float* dx, float* dy) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (dx != nullptr) *dx = g_gyro_dx;
    if (dy != nullptr) *dy = g_gyro_dy;
    g_gyro_dx = 0.0f;
    g_gyro_dy = 0.0f;
}
