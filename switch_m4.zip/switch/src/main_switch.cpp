// Milestone 1 entry point for Nintendo Switch homebrew.
//
// Boots the recompiled game with no graphics, input or UI so we can see
// whether the runtime, the generated code and the threading all work on
// Horizon. Everything the PC frontend (src/main/main.cpp) does through SDL,
// RT64 and RecompFrontend is replaced by a stub here:
//
//   * graphics: a renderer that accepts and discards every display list
//   * audio:    a simulated sound buffer that drains in real time, so the
//               game's audio thread paces itself like it would on a speaker
//   * input:    one connected controller that presses nothing
//   * ROM:      read from sdmc:/switch/snprecomp/rom.z64, validated and copied
//               into the app folder by recomp::select_rom, then started
//               directly (no launcher)
//
// Logs: sdmc:/switch/snprecomp/log.txt (stdout), err.txt (stderr).
// This file deliberately includes no libnx headers (see switch_platform.cpp).

#include <atomic>
#include <chrono>
#include <cinttypes>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <deque>
#include <exception>
#include <filesystem>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "ultramodern/ultra64.h"
#include "ultramodern/ultramodern.hpp"
#include "librecomp/game.hpp"

namespace fs = std::filesystem;

// --- Things defined elsewhere in the project --------------------------------

extern "C" void recomp_entrypoint(uint8_t* rdram, recomp_context* ctx); // RecompiledFuncs
void register_snp_overlays();                                           // src/main/register_overlays.cpp
bool snp_rom_check(const recomp::GameEntry& game, const std::vector<uint8_t>& rom); // src/game/rom_version.cpp
RspExitReason n_aspMain(uint8_t* rdram, uint32_t ucode_addr);           // rsp/n_aspMain.cpp
bool snp_switch_applet_loop();                                          // switch_platform.cpp
bool snp_switch_audio_init();                                           // switch_platform.cpp
bool snp_switch_input_init(const char* config_path);                    // switch_input.cpp
void snp_switch_input_poll();                                           // switch_input.cpp
void snp_switch_input_flush_debug();                                    // switch_input.cpp
bool snp_switch_input_get(int controller, uint16_t* buttons, float* x, float* y); // switch_input.cpp
void snp_switch_audio_push(const int16_t* stereo, size_t frames, uint32_t sample_rate); // switch_platform.cpp
void snp_report_fatal_error(const char* message);                       // switch_stubs.cpp

// --- Paths ---------------------------------------------------------------------

static const fs::path app_dir = "sdmc:/switch/snprecomp";
static const fs::path rom_path = app_dir / "rom.z64";

// --- Stub renderer ---------------------------------------------------------------

namespace {
class NullRenderer final : public ultramodern::renderer::RendererContext {
public:
    NullRenderer() {
        setup_result = ultramodern::renderer::SetupResult::Success;
        chosen_api = static_cast<ultramodern::renderer::GraphicsApi>(0);
    }
    bool valid() override { return true; }
    bool update_config(const ultramodern::renderer::GraphicsConfig&, const ultramodern::renderer::GraphicsConfig&) override { return false; }
    void enable_instant_present() override {}
    void send_dl(const OSTask*) override {
        static std::atomic<uint32_t> count{0};
        uint32_t n = ++count;
        if (n == 1 || n % 300 == 0) printf("[snp-switch] graphics task #%" PRIu32 "\n", n);
    }
    void send_dummy_workload(uint32_t) override {}
    void update_screen() override {}
    void shutdown() override {}
    uint32_t get_display_framerate() const override { return 60; }
    float get_resolution_scale() const override { return 1.0f; }
};
}

static std::unique_ptr<ultramodern::renderer::RendererContext> create_null_renderer(uint8_t*, ultramodern::renderer::WindowHandle, bool) {
    printf("[snp-switch] creating the null renderer\n");
    return std::make_unique<NullRenderer>();
}

// --- Graphics / windowing (none) -------------------------------------------------

static ultramodern::gfx_callbacks_t::gfx_data_t create_gfx() {
    return {};
}

static ultramodern::renderer::WindowHandle create_window(ultramodern::gfx_callbacks_t::gfx_data_t) {
    // The runtime wants a non-null handle; WindowHandle is a pointer type in
    // this build and nothing ever dereferences it.
    return reinterpret_cast<ultramodern::renderer::WindowHandle>(static_cast<uintptr_t>(1));
}

static void update_gfx(void*) {}

// --- Audio: a simulated sound buffer -----------------------------------------------
// Same bookkeeping as the PC build's SDL queue (src/main/main.cpp), but the
// "device" is a clock: queued frames drain at the game's sample rate.

static std::mutex audio_mutex;
static uint32_t game_frequency = 44100;
static double queued_frames = 0.0;
static std::chrono::steady_clock::time_point last_drain = std::chrono::steady_clock::now();
static std::deque<size_t> queued_chunks; // frames in each chunk not yet fully played, oldest first
static size_t queued_chunk_frames = 0;   // their total

// audio_mutex must be held.
static size_t drain_to_now() {
    auto now = std::chrono::steady_clock::now();
    double elapsed = std::chrono::duration<double>(now - last_drain).count();
    last_drain = now;
    queued_frames -= elapsed * game_frequency;
    if (queued_frames < 0.0) {
        queued_frames = 0.0;
    }
    size_t queued = static_cast<size_t>(queued_frames);
    while (!queued_chunks.empty() && queued_chunk_frames - queued_chunks.front() >= queued) {
        queued_chunk_frames -= queued_chunks.front();
        queued_chunks.pop_front();
    }
    return queued;
}

extern "C" uint32_t snp_ai_length() {
    std::lock_guard<std::mutex> lock(audio_mutex);
    size_t queued = drain_to_now();
    if (queued_chunks.empty()) {
        return 0;
    }
    size_t after_current = queued_chunk_frames - queued_chunks.front();
    size_t current = queued > after_current ? queued - after_current : 0;
    return static_cast<uint32_t>(current * 2 * sizeof(int16_t));
}

extern "C" uint32_t snp_ai_status() {
    std::lock_guard<std::mutex> lock(audio_mutex);
    drain_to_now();
    return queued_chunks.size() >= 3 ? 0x80000000u : 0;
}

static void queue_samples(int16_t* audio_data, size_t sample_count) {
    uint32_t rate;
    {
        std::lock_guard<std::mutex> lock(audio_mutex);
        drain_to_now();
        static uint32_t chunks = 0;
        if (++chunks == 1 || chunks % 300 == 0) printf("[snp-switch] audio chunk #%" PRIu32 " (%zu samples)\n", chunks, sample_count);
        // Safety cap so a burst can't pile up latency forever.
        if (queued_frames > game_frequency / 2) {
            queued_frames = 0.0;
            queued_chunks.clear();
            queued_chunk_frames = 0;
        }
        size_t frames = sample_count / 2; // stereo, interleaved
        queued_frames += static_cast<double>(frames);
        queued_chunks.push_back(frames);
        queued_chunk_frames += frames;
        rate = game_frequency;
    }
    // The simulated queue above still paces the game; this makes it audible.
    snp_switch_audio_push(audio_data, sample_count / 2, rate);
}

static size_t get_frames_remaining() {
    std::lock_guard<std::mutex> lock(audio_mutex);
    drain_to_now();
    return static_cast<size_t>(queued_frames);
}

static void set_frequency(uint32_t frequency) {
    std::lock_guard<std::mutex> lock(audio_mutex);
    game_frequency = frequency;
}

// --- Input: Joy-Con / Pro Controller via libnx (switch_input.cpp) -------------------------

static void poll_input() {
    snp_switch_input_poll();
}

static bool get_input(int controller_num, uint16_t* buttons, float* x, float* y) {
    return snp_switch_input_get(controller_num, buttons, x, y);
}

static void set_rumble(int, bool) {}

static ultramodern::input::connected_device_info_t get_connected_device_info(int controller_num) {
    if (controller_num != 0) {
        return ultramodern::input::connected_device_info_t{
            .connected_device = ultramodern::input::Device::None,
            .connected_pak = ultramodern::input::Pak::None,
        };
    }
    return ultramodern::input::connected_device_info_t{
        .connected_device = ultramodern::input::Device::Controller,
        .connected_pak = ultramodern::input::Pak::None,
    };
}

// --- Misc callbacks ---------------------------------------------------------------------

static void vi_callback() {
    static uint32_t vi_count = 0;
    if (++vi_count % 600 == 0) {
        printf("[snp-switch] %" PRIu32 " VI interrupts\n", vi_count);
    }
}

static void message_box(const char* message) {
    fprintf(stderr, "[snp-switch] MESSAGE: %s\n", message);
    fflush(stderr);
}

static std::string get_game_thread_name(const OSThread* t) {
    return "Game " + std::to_string(t->id);
}

static RspUcodeFunc* get_rsp_microcode(const OSTask* task) {
    switch (task->t.type) {
    case M_AUDTASK:
        return n_aspMain;
    default:
        fprintf(stderr, "No RSP microcode registered for task type %" PRIu32 ".\n", task->t.type);
        return nullptr;
    }
}

// --- Game registration (same entries as src/main/main.cpp) -------------------------------

static std::vector<recomp::GameEntry> supported_games = {
    {
        .rom_hash = 0xec641b62243b72b9ULL,
        .internal_name = "TSUMI TO BATSU",
        .display_name = "Sin and Punishment (Japan)",
        .game_id = u8"snp.n64.jp.1.0",
        .mod_game_id = "snp",
        .save_type = recomp::SaveType::Eep4k,
        .thumbnail_bytes = {},
        .is_enabled = true,
        .decompression_routine = nullptr,
        .has_compressed_code = false,
        .entrypoint_address = (gpr)(int32_t)0x80025C00u,
        .entrypoint = recomp_entrypoint,
        .on_init_callback = nullptr,
    },
    {
        .rom_hash = 0x912f22306cafedd2ULL,
        .internal_name = "Sin and Punishment",
        .display_name = "Sin and Punishment (English translation)",
        .game_id = u8"snp.n64.en.fan",
        .mod_game_id = "snp",
        .save_type = recomp::SaveType::Eep4k,
        .thumbnail_bytes = {},
        .is_enabled = true,
        .decompression_routine = nullptr,
        .has_compressed_code = false,
        .entrypoint_address = (gpr)(int32_t)0x80025C00u,
        .entrypoint = recomp_entrypoint,
        .on_init_callback = nullptr,
    },
};

// --- Process level -------------------------------------------------------------------------

[[noreturn]] static void report_unhandled_exception_and_abort() {
    std::string message = "std::terminate() called with no active exception";
    if (std::exception_ptr eptr = std::current_exception()) {
        try {
            std::rethrow_exception(eptr);
        } catch (const std::exception& e) {
            message = std::string("uncaught C++ exception: ") + e.what();
        } catch (...) {
            message = "uncaught C++ exception of an unrecognized type";
        }
    }
    fflush(stdout);
    snp_report_fatal_error(message.c_str());
    std::abort();
}

int main(int argc, char** argv) {
    std::error_code ec;
    fs::create_directories(app_dir / "config", ec);

    // stdout and stderr go to separate files: two streams on one file would
    // overwrite each other's output.
    std::freopen((app_dir / "log.txt").string().c_str(), "w", stdout);
    std::freopen((app_dir / "err.txt").string().c_str(), "w", stderr);
    std::setvbuf(stdout, nullptr, _IOLBF, 0);
    std::setvbuf(stderr, nullptr, _IOLBF, 0);
    printf("[snp-switch] milestone 1 starting\n");

    std::set_terminate(report_unhandled_exception_and_abort);

    printf("[snp-switch] audio output: %s\n", snp_switch_audio_init() ? "ok" : "unavailable");
    snp_switch_input_init((app_dir / "input.cfg").string().c_str());

    // Keep the system happy (HOME button, sleep): pump applet events from a
    // helper thread, since this one blocks inside recomp::start.
    new std::thread([] {
        while (snp_switch_applet_loop()) {
            snp_switch_input_flush_debug();
            std::this_thread::sleep_for(std::chrono::milliseconds(16));
        }
        printf("[snp-switch] applet asked us to exit\n");
        fflush(stdout);
        fflush(stderr);
        std::_Exit(EXIT_SUCCESS);
    });

    recomp::Version project_version{};
    if (!recomp::Version::from_string("0.2.0", project_version)) {
        fprintf(stderr, "Invalid version string\n");
        return EXIT_FAILURE;
    }

    register_snp_overlays();
    recomp::register_config_path(app_dir / "config");
    for (const auto& game : supported_games) {
        recomp::register_game(game);
    }
    recomp::set_rom_check(snp_rom_check);

    if (!fs::exists(rom_path, ec)) {
        fprintf(stderr, "No ROM found. Put your ROM at %s\n", rom_path.string().c_str());
        printf("[snp-switch] no ROM at %s\n", rom_path.string().c_str());
        return EXIT_FAILURE;
    }

    // Try the English translation first, then the Japanese release.
    std::u8string chosen;
    for (const std::u8string& id : { std::u8string(u8"snp.n64.en.fan"), std::u8string(u8"snp.n64.jp.1.0") }) {
        auto result = recomp::select_rom(rom_path, id);
        printf("[snp-switch] select_rom(%s) -> %d (0 = good?)\n", reinterpret_cast<const char*>(id.c_str()), static_cast<int>(result));
        if (result == recomp::RomValidationError::Good) {
            chosen = id;
            break;
        }
    }
    if (chosen.empty()) {
        fprintf(stderr, "The ROM was not accepted as any supported game (see log.txt).\n");
        return EXIT_FAILURE;
    }
    printf("[snp-switch] starting game %s\n", reinterpret_cast<const char*>(chosen.c_str()));
    recomp::start_game(chosen, "");

    recomp::rsp::callbacks_t rsp_callbacks{
        .get_rsp_microcode = get_rsp_microcode,
    };

    ultramodern::renderer::callbacks_t renderer_callbacks{
        .create_render_context = create_null_renderer,
    };

    ultramodern::gfx_callbacks_t gfx_callbacks{
        .create_gfx = create_gfx,
        .create_window = create_window,
        .update_gfx = update_gfx,
    };

    ultramodern::audio_callbacks_t audio_callbacks{
        .queue_samples = queue_samples,
        .get_frames_remaining = get_frames_remaining,
        .set_frequency = set_frequency,
    };

    ultramodern::input::callbacks_t input_callbacks{
        .poll_input = poll_input,
        .get_input = get_input,
        .set_rumble = set_rumble,
        .get_connected_device_info = get_connected_device_info,
    };

    ultramodern::events::callbacks_t events_callbacks{
        .vi_callback = vi_callback,
        .gfx_init_callback = nullptr,
    };

    ultramodern::error_handling::callbacks_t error_handling_callbacks{
        .message_box = message_box,
    };

    ultramodern::threads::callbacks_t threads_callbacks{
        .get_game_thread_name = get_game_thread_name,
    };

    recomp::start({
        .argc = argc,
        .argv = argv,
        .project_version = project_version,
        .window_handle = {}, // created by gfx_callbacks.create_window
        .rsp_callbacks = rsp_callbacks,
        .renderer_callbacks = renderer_callbacks,
        .audio_callbacks = audio_callbacks,
        .input_callbacks = input_callbacks,
        .gfx_callbacks = gfx_callbacks,
        .events_callbacks = events_callbacks,
        .error_handling_callbacks = error_handling_callbacks,
        .threads_callbacks = threads_callbacks,
        .message_queue_control = {}, // the runtime's defaults
    });

    // The game's threads are never joined by the runtime; exit directly.
    printf("[snp-switch] recomp::start returned\n");
    fflush(stdout);
    fflush(stderr);
    std::_Exit(EXIT_SUCCESS);
}
