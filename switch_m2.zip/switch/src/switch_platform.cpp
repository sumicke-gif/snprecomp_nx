// The only file that includes libnx headers: libnx defines generic names
// (Result, Mutex, Semaphore, Event, ...) that could collide with the N64
// runtime's headers, so everything else stays away from <switch.h>.

#include <switch.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <malloc.h>
#include <mutex>
#include <thread>
#include <vector>

// Returns false once the system wants the application to close.
bool snp_switch_applet_loop() {
    return appletMainLoop();
}

// libnx does not implement __syscall_thread_detach, so pthread_detach (used by
// std::thread::detach) fails with ENOSYS and the game dies with "Function not
// implemented". Reporting success is enough: the SwitchWakerHD port did the same.
extern "C" int __syscall_thread_detach(...) {
    return 0;
}

// --- Audio output -----------------------------------------------------------------
//
// The game produces 16-bit stereo audio at its own sample rate (about 22 kHz).
// The Switch's audout service plays fixed 48 kHz stereo, so each chunk is
// resampled (linear interpolation) into a ring buffer, and a thread keeps four
// 1024-frame audout buffers filled from it. If the ring runs dry the buffer is
// padded with silence; if it overflows, the newest frames are dropped.

namespace {

constexpr size_t kBufFrames = 1024;
constexpr size_t kBufCount = 4;
constexpr size_t kBufBytes = kBufFrames * 2 * sizeof(int16_t); // 4096 = 0x1000, as audout wants
constexpr size_t kRingFrames = 48000 / 4;                      // 250 ms of 48 kHz audio

bool g_audio_ok = false;
AudioOutBuffer g_out[kBufCount];
int16_t* g_mem[kBufCount];

std::mutex g_mutex;
std::vector<int16_t> g_ring(kRingFrames * 2);
size_t g_head = 0;  // next frame to read
size_t g_count = 0; // frames stored
double g_pos = 0.0; // resampler position, relative to the current chunk
int16_t g_prev[2] = { 0, 0 }; // last frame of the previous chunk
uint64_t g_dropped = 0;
uint64_t g_underruns = 0;

void fill_buffer(int16_t* dst) {
    std::lock_guard<std::mutex> lock(g_mutex);
    size_t n = std::min(kBufFrames, g_count);
    for (size_t i = 0; i < n; i++) {
        size_t idx = ((g_head + i) % kRingFrames) * 2;
        dst[i * 2] = g_ring[idx];
        dst[i * 2 + 1] = g_ring[idx + 1];
    }
    g_head = (g_head + n) % kRingFrames;
    g_count -= n;
    if (n < kBufFrames) {
        memset(dst + n * 2, 0, (kBufFrames - n) * 2 * sizeof(int16_t));
        g_underruns++;
    }
}

void submit_buffer(AudioOutBuffer* b) {
    fill_buffer(static_cast<int16_t*>(b->buffer));
    b->data_size = kBufBytes;
    b->data_offset = 0;
    audoutAppendAudioOutBuffer(b);
}

void audio_thread() {
    uint64_t buffers = 0;
    for (;;) {
        AudioOutBuffer* released = nullptr;
        u32 count = 0;
        Result rc = audoutWaitPlayFinish(&released, &count, UINT64_MAX);
        if (R_FAILED(rc) || released == nullptr) {
            std::this_thread::sleep_for(std::chrono::milliseconds(5));
            continue;
        }
        submit_buffer(released);
        if (++buffers % 470 == 0) { // about every 10 seconds
            uint64_t dropped, underruns;
            {
                std::lock_guard<std::mutex> lock(g_mutex);
                dropped = g_dropped;
                underruns = g_underruns;
            }
            printf("[snp-switch] audio: %llu buffers played, %llu underruns, %llu frames dropped\n",
                   (unsigned long long)buffers, (unsigned long long)underruns, (unsigned long long)dropped);
        }
    }
}

} // namespace

bool snp_switch_audio_init() {
    if (R_FAILED(audoutInitialize())) {
        return false;
    }
    if (R_FAILED(audoutStartAudioOut())) {
        return false;
    }
    for (size_t i = 0; i < kBufCount; i++) {
        g_mem[i] = static_cast<int16_t*>(memalign(0x1000, kBufBytes));
        if (g_mem[i] == nullptr) {
            return false;
        }
        memset(g_mem[i], 0, kBufBytes);
        memset(&g_out[i], 0, sizeof(g_out[i]));
        g_out[i].next = nullptr;
        g_out[i].buffer = g_mem[i];
        g_out[i].buffer_size = kBufBytes;
        g_out[i].data_size = kBufBytes;
        g_out[i].data_offset = 0;
        audoutAppendAudioOutBuffer(&g_out[i]);
    }
    g_audio_ok = true;
    new std::thread(audio_thread); // never joined: the process exits with _Exit
    return true;
}

// `in` holds `frames` interleaved stereo frames at `rate` Hz.
void snp_switch_audio_push(const int16_t* in, size_t frames, uint32_t rate) {
    if (!g_audio_ok || frames == 0 || rate == 0) {
        return;
    }
    std::lock_guard<std::mutex> lock(g_mutex);
    const double step = double(rate) / 48000.0;
    // Source frame i, where -1 means the last frame of the previous chunk.
    auto src = [&](long i, int ch) -> double {
        return i < 0 ? double(g_prev[ch]) : double(in[size_t(i) * 2 + ch]);
    };
    while (g_pos < double(frames) - 1.0) {
        long i = long(std::floor(g_pos));
        double frac = g_pos - double(i);
        if (g_count >= kRingFrames) {
            g_dropped++;
        } else {
            size_t w = ((g_head + g_count) % kRingFrames) * 2;
            for (int ch = 0; ch < 2; ch++) {
                double a = src(i, ch);
                double b = src(i + 1, ch);
                g_ring[w + ch] = int16_t(a + (b - a) * frac);
            }
            g_count++;
        }
        g_pos += step;
    }
    g_pos -= double(frames);
    g_prev[0] = in[(frames - 1) * 2];
    g_prev[1] = in[(frames - 1) * 2 + 1];
}
