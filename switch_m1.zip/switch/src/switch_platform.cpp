// The only file that includes libnx headers: libnx defines generic names
// (Result, Mutex, Semaphore, Event, ...) that could collide with the N64
// runtime's headers, so everything else stays away from <switch.h>.

#include <switch.h>

// Returns false once the system wants the application to close.
bool snp_switch_applet_loop() {
    return appletMainLoop();
}

// libnx does not implement __syscall_thread_detach, so pthread_detach (used by
// std::thread::detach) fails with ENOSYS and the game dies with "Function not
// implemented". Reporting success is enough: the SwitchWakerHD port did the same.
extern "C" int __syscall_thread_detach(...) {
    return 0;
}
