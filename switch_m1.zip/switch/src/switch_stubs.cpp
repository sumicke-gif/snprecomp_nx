// Empty stand-ins for the PC-only parts of the project, so milestone 1 links.
// The real versions live in src/game/ and src/main/ and depend on the PC
// frontend (RT64, recompui). Each gets a proper Switch implementation later.

#include <cstddef>
#include <cstdint>
#include <cstdio>

#include "librecomp/overlays.hpp" // SectionTableEntry

extern "C" {

// src/game/display_list.cpp: widescreen/interpolation fixups of a frame's
// display list. Nothing draws yet, so nothing to fix up.
void snp_display_list_hook(uint8_t* rdram, int32_t task) {
    (void)rdram;
    (void)task;
}

// src/game/extras.cpp: the Enhancements and Cheats tabs.
void snp_extras_frame(uint8_t* rdram) {
    (void)rdram;
}

void snp_extras_saving(uint8_t* rdram) {
    (void)rdram;
}

} // extern "C"

// src/main/crash_handler.cpp (Windows/Linux crash logs).
void snp_install_crash_handler(const SectionTableEntry* sections, size_t num_sections) {
    (void)sections;
    (void)num_sections;
}

void snp_report_fatal_error(const char* message) {
    fprintf(stderr, "[snp-switch] FATAL: %s\n", message);
    fflush(stderr);
}
