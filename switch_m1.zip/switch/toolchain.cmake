# Cross-compiling for the Nintendo Switch (Horizon OS) with devkitA64.
#
#   cmake -S switch -B build-nx -G Ninja \
#         -DCMAKE_TOOLCHAIN_FILE=$PWD/switch/toolchain.cmake -DCMAKE_BUILD_TYPE=Release
#
# The flags mirror the ones the compile-check scripts (switch/tools/) used, which
# are the standard devkitPro Switch flags.

if (NOT DEFINED ENV{DEVKITPRO})
    message(FATAL_ERROR "DEVKITPRO is not set (is this the devkitpro container?)")
endif()
set(DKP "$ENV{DEVKITPRO}")

set(CMAKE_SYSTEM_NAME Generic)
set(CMAKE_SYSTEM_PROCESSOR aarch64)

set(CMAKE_C_COMPILER   "${DKP}/devkitA64/bin/aarch64-none-elf-gcc")
set(CMAKE_CXX_COMPILER "${DKP}/devkitA64/bin/aarch64-none-elf-g++")
set(CMAKE_ASM_COMPILER "${DKP}/devkitA64/bin/aarch64-none-elf-gcc")
set(CMAKE_AR           "${DKP}/devkitA64/bin/aarch64-none-elf-gcc-ar" CACHE FILEPATH "")
set(CMAKE_RANLIB       "${DKP}/devkitA64/bin/aarch64-none-elf-gcc-ranlib" CACHE FILEPATH "")

set(SNP_ARCH "-march=armv8-a+crc+crypto -mtune=cortex-a57 -mtp=soft -fPIE")
set(SNP_INC  "-I${DKP}/libnx/include -I${DKP}/portlibs/switch/include")

set(CMAKE_C_FLAGS_INIT   "${SNP_ARCH} -D__SWITCH__ -ffunction-sections -fdata-sections ${SNP_INC}")
set(CMAKE_CXX_FLAGS_INIT "${SNP_ARCH} -D__SWITCH__ -ffunction-sections -fdata-sections ${SNP_INC}")
set(CMAKE_ASM_FLAGS_INIT "${SNP_ARCH}")
set(CMAKE_EXE_LINKER_FLAGS_INIT "${SNP_ARCH} -specs=${DKP}/libnx/switch.specs -Wl,--gc-sections")

# Linking a test program needs the Switch specs and a loader; only compile in checks.
set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)

set(CMAKE_FIND_ROOT_PATH "${DKP}/portlibs/switch" "${DKP}/libnx")
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_PACKAGE ONLY)
